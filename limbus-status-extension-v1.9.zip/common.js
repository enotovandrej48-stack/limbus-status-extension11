import OBR, { isImage, buildImage, buildText } from "https://cdn.jsdelivr.net/npm/@owlbear-rodeo/sdk@3.0.0/+esm";
export { OBR, isImage, buildImage, buildText };

export const NS = "com.limbus.status";
export const META = `${NS}/data`;     // { burn: 3, bleed: 2, ... } хранится в метаданных токена (сохраняется в сцене)
export const LOCAL = `${NS}/local`;   // метка локальных значков на токене

const S = (id, ru, group, desc = "") => ({ id, ru, group, desc });
export const STATUSES = [
  S("burn", "Ожог", 0, "В конце раунда получите урон HP, равный стакам Ожога, затем стаки уменьшаются вдвое (округление вниз)."),
  S("frostbite", "Обморожение", 0, "В конце раунда получите урон ST, равный стакам, затем стаки уменьшаются вдвое (округление вниз)."),
  S("bleed", "Кровотечение", 0, "Каждое Действие или Реакция: урон HP, равный стакам, затем стаки уменьшаются вдвое (округление вниз)."),
  S("rupture", "Разрыв", 0, "При попадании атакующий может активировать: урон HP = стакам, затем снять все. В конце раунда снимается."),
  S("tremor", "Тремор", 0, "При попадании атакующий может активировать: урон ST = стакам, затем снять все. В конце раунда снимается."),
  S("sinking", "Погружение", 0, "При попадании атакующий может активировать: урон SP = стакам (при 0 SP — урон HP), затем снять все. В конце раунда снимается."),
  S("poise", "Хладнокровие", 1, "При попадании бросьте D10: если ≤ Poise, можно нанести Критический удар и потерять весь Poise ИЛИ получить 1 Critical и сбросить Poise до 1."),
  S("critical", "Критический", 1, "При Критическом ударе +1D10 урона HP за каждый Critical, затем Critical снимается. Если нет Poise — получите 1 Poise."),
  S("ruin", "Руина", 2), S("devastation", "Разрушение", 2), S("paralysis", "Паралич", 2),
  S("protection", "Защита", 2), S("stagger_protection", "Защита от шатания", 2), S("slash_protection", "Защита от режущего", 2, "Получаете на 1 меньше урона HP и ST (до сопротивления) от атак этого типа за каждый стак. Разные типы защиты активны одновременно. В конце раунда снимается."), S("pierce_protection", "Защита от пронзающего", 2, "Получаете на 1 меньше урона HP и ST (до сопротивления) от атак этого типа за каждый стак. Разные типы защиты активны одновременно. В конце раунда снимается."), S("blunt_protection", "Защита от дробящего", 2, "Получаете на 1 меньше урона HP и ST (до сопротивления) от атак этого типа за каждый стак. Разные типы защиты активны одновременно. В конце раунда снимается."),
  S("fragile", "Уязвимость", 2), S("stagger_fragile", "Уязвимость к шатанию", 2), S("slash_fragile", "Уязвимость к режущему", 2, "Получаете на 1 больше урона HP и ST (до сопротивления) от атак этого типа за каждый стак. В конце раунда снимается."), S("pierce_fragile", "Уязвимость к пронзающему", 2, "Получаете на 1 больше урона HP и ST (до сопротивления) от атак этого типа за каждый стак. В конце раунда снимается."), S("blunt_fragile", "Уязвимость к дробящему", 2, "Получаете на 1 больше урона HP и ST (до сопротивления) от атак этого типа за каждый стак. В конце раунда снимается."),
  S("strength", "Сила", 2), S("feeble", "Слабость", 2), S("endurance", "Выносливость", 2, "Повышает силу защитных кубиков (Блок и Уклон) на число стаков. В конце раунда снимается полностью."), S("disarm", "Обезоруживание", 2),
  S("haste", "Скорость", 2), S("bind", "Связывание", 2), S("smoke", "Дым", 2),
  S("charge", "Заряд", 2), S("charge_barrier", "Барьер заряда", 2), S("overcharge", "Перезаряд", 2),
  S("mark", "Метка", 2), S("staggered", "Шатание", 2), S("panic", "Паника", 2), S("defeated", "Повержен", 2),
  S("recycled_evade", "Recycled Evade", 2, "После победы Уклонением можно уклониться снова без траты реакции, со штрафом −2 к силе кубика, который растёт на 2 после каждой победы. Снимается в конце раунда."),
  S("thirst", "Жажда", 3, "Перемещение −4."),
  S("hunger", "Голод", 3, "Сопротивление ST ухудшается на одну ступень для всех типов урона (Нормальный ×1 → Слабый ×1.5)."),
  S("poison", "Яд", 3, "Сопротивление HP ухудшается на одну ступень для всех типов урона (Нормальный ×1 → Слабый ×1.5)."),
];
export const GROUPS = ["Накопительные (урон)", "Poise и Critical", "Прочие эффекты", "Выживание и яд"];
export const iconUrl = (id) => new URL(`icons/${id}.png`, import.meta.url).href;
export const getData = (item) => item.metadata[META] || {};
export const nameOf = (it) => it.text?.plainText || it.name || "Токен";

function write(it, d) {
  Object.keys(d).forEach((k) => !(d[k] > 0) && delete d[k]);
  if (Object.keys(d).length) it.metadata[META] = d; else delete it.metadata[META];
}

// Правила Poise/Critical: Poise 0→>0 даёт Critical 1; Poise 0 обнуляет Critical; Critical без Poise даёт 1 Poise
export function setStatus(d, key, v) {
  v = Math.max(0, Math.floor(v) || 0); const old = d[key] || 0; d[key] = v;
  if (key === "poise") { if (v === 0) d.critical = 0; else if (old === 0 && !(d.critical > 0)) d.critical = 1; }
  if (key === "critical" && v > old && !(d.poise > 0)) d.poise = 1;
  return d;
}
export async function setCount(itemId, key, n) {
  n = Math.max(0, Math.floor(Number(n)) || 0);
  await OBR.scene.items.updateItems([itemId], ([it]) => { const d = { ...getData(it) }; setStatus(d, key, n); write(it, d); });
}

export async function clearToken(itemId) {
  await OBR.scene.items.updateItems([itemId], ([it]) => delete it.metadata[META]);
}

// ---------- Лист персонажа (хранится в метаданных токена) ----------
export const CHAR = `${NS}/char`;
export const STAT_KEYS = [["fort", "Стойкость", "#d0362f"], ["prud", "Благоразумие", "#d8cfa6"], ["just", "Справедливость", "#2fb5bd"], ["charm", "Очарование", "#b9a3df"], ["ins", "Понимание", "#e0b030"], ["temp", "Умеренность", "#b365ad"]];
export const NEG = new Set("burn frostbite bleed rupture tremor sinking ruin devastation paralysis fragile stagger_fragile slash_fragile pierce_fragile blunt_fragile feeble disarm bind staggered panic defeated thirst hunger poison mark smoke".split(" "));
export const DMG = [["slash", "Режущий"], ["pierce", "Пронзающий"], ["blunt", "Дробящий"]];
export const RES = [["fatal", "Смертельный", 2], ["weak", "Слабый", 1.5], ["normal", "Нормальный", 1], ["endured", "Выдержал", 0.5], ["ineffective", "Неэффективно", 0.25], ["immune", "Иммунитет", 0]];
const nz = () => ({ slash: "normal", pierce: "normal", blunt: "normal" });
// ---------- Оружие (4 пресета) и броня ----------
export const FORMS = [["small", "Маленький (+1 контр-реакция)"], ["medium", "Средний (+2 макс. кубика)"], ["long", "Длинный"], ["sturdy", "Прочный (+1 реакция блока)"], ["hybrid", "Гибридный"], ["lowcal", "Малый калибр (дальний)"], ["highcal", "Большой калибр (+2 макс.)"], ["reactive", "Реактивный (дальний)"]];
export const HANDS = [["o1", "Наступательное 1-ручное (+1 сила)"], ["o2", "Наступательное 2-ручное (+2 силы)"], ["d1", "Защитное 1-ручное"], ["d2", "Защитное 2-ручное"]];
export const PROPS = [["balanced", "Сбалансированный (+2 EP, +1 макс. Света)"], ["armored", "Бронированный (+1 к силе Блока)"], ["swift", "Быстрый (+1 к силе Уклонения)"]];
export const autoDice = (w) => ({ max: 10 + (w.form === "medium" || w.form === "highcal" ? 2 : 0), pow: w.hand === "o1" ? 1 : w.hand === "o2" ? 2 : 0 });
const newWeapon = (i) => ({ name: `Оружие ${i + 1}`, kind: "melee", type: "slash", form: "small", hand: "o1", max: 10, pow: 1, rank: 0, attach: "", anim: "slash_1", feet: 10, win: [], lose: [] });
const newOutfit = () => ({ name: "Наряд", prop: "balanced", bmax: 10, emax: 12, bpow: 0, epow: 0, bw: [], bl: [], ew: [], el: [], notes: "" });
export const activeWeapon = (c) => c.weapons[c.wActive] || c.weapons[0];
export function defense(c, fx = {}) {   // защитные кубики: Блок 1d10 + Уклон 1d12 + Выносливость + свойство брони
  const o = c.outfit, d = derived(c), en = fx.endurance || 0;
  return { bmax: o.bmax, emax: o.emax, bbonus: d.def + en + o.bpow + (o.prop === "armored" ? 1 : 0), ebonus: d.evd + en + o.epow + (o.prop === "swift" ? 1 : 0), step: o.prop === "swift" ? 1 : 2 };
}
export async function setActiveWeapon(itemId, idx, force = false) {   // смена оружия — один раз за раунд
  let res = "ok";
  await OBR.scene.items.updateItems([itemId], ([it]) => {
    const c = getChar(it); if (c.wActive === idx) { res = "same"; return; }
    if (c.swapped && !force) { res = "denied"; return; }
    c.wActive = idx; c.swapped = true; it.metadata[CHAR] = c;
  });
  return res;
}
// эффекты оружия/брони: rows = [{id, n, who: "me"|"him"}], owner — владелец эффекта, opp — противник
export async function applyRows(rows, ownerId, oppId) {
  const by = {}, out = [];
  for (const r of rows || []) if (r?.id && r.n > 0) (by[r.who === "me" ? ownerId : oppId] ||= []).push({ id: r.id, n: +r.n });
  for (const [tid, fx] of Object.entries(by)) { await addStatuses(tid, fx); out.push(...fx.map((f) => `+${f.n} ${STATUSES.find((s) => s.id === f.id)?.ru || f.id}${tid === ownerId ? " (себе)" : ""}`)); }
  return out;
}
export function getChar(it) {
  const c = it.metadata[CHAR] || {};
  return { rank: 0, moveMod: 0, rUsed: 0, rBonus: 0, swapped: false, wActive: 0, ...c, owner: c.owner && c.owner !== "gm" ? c.owner : "", access: c.access ?? (c.owner && c.owner !== "gm" ? "player" : "gm"), stats: { fort: 0, prud: 0, just: 0, charm: 0, ins: 0, temp: 0, ...c.stats }, res: { hp: { ...nz(), ...c.res?.hp }, st: { ...nz(), ...c.res?.st } },
    weapons: [0, 1, 2, 3].map((i) => ({ ...newWeapon(i), ...(c.weapons?.[i] || {}) })), outfit: { ...newOutfit(), ...c.outfit } };
}
export const canUse = (c, role, me) => role === "GM" || c.access === "all" || (c.access === "player" && c.owner === me);
export function derived(c) {
  const s = c.stats, r = c.rank;
  return { hp: 64 + s.fort * 8 + r * 32, st: 20 + s.charm * 4 + r * 4, sp: 15 + s.prud * 3, light: 3 + r, att: r, def: s.temp, evd: s.ins,
    move: 6 + s.just, exp: (r - 1) * 24, actions: [1, 1, 1, 2, 2, 3][r] ?? 3, reactions: Math.max(0, r + (c.rBonus || 0)), gear: r + 1 };
}
// множитель сопротивления; Яд ухудшает сопротивление HP, Голод — сопротивление ST на одну ступень
export function mult(c, kind, type, fx) {
  let i = RES.findIndex((x) => x[0] === c.res[kind][type]); if (i < 0) i = 2;
  if ((kind === "hp" ? fx.poison : fx.hunger) > 0) i = Math.max(0, i - 1);
  return RES[i][2];
}
function hit(it, hp, st) { // внутри updateItems: списывает HP/ST, ставит Повержен / Шатание
  const c = getChar(it), d = derived(c);
  c.hp = Math.max(0, (c.hp ?? d.hp) - hp); c.st = Math.max(0, (c.st ?? d.st) - st); it.metadata[CHAR] = c;
  const s = { ...getData(it) }; if (c.hp <= 0) s.defeated = 1; if (c.st <= 0 && st > 0) s.staggered = s.staggered || 1; write(it, s);
  return c;
}
export async function setChar(itemId, fn) {
  await OBR.scene.items.updateItems([itemId], ([it]) => { const c = getChar(it); fn(c); it.metadata[CHAR] = c; });
}
export async function applyDamage(id, { hp = 0, st = 0, type = "slash" }) {
  let out;
  await OBR.scene.items.updateItems([id], ([it]) => {
    if (!it.metadata[CHAR]) return;
    const c = getChar(it), fx = getData(it), prot = fx[type + "_protection"] || 0, frag = fx[type + "_fragile"] || 0, adj = (v) => (v > 0 ? Math.max(0, v - prot + frag) : 0),
      h = Math.floor(adj(hp) * mult(c, "hp", type, fx)), s = Math.floor(adj(st) * mult(c, "st", type, fx));
    const n = hit(it, h, s); out = `${nameOf(it)}: −${h} HP, −${s} ST → HP ${n.hp}, ST ${n.st}`;
  });
  OBR.notification.show(out || "У цели нет листа персонажа: урон не применён", out ? "WARNING" : "DEFAULT");
}

// Кровотечение: каждое Действие/Реакция — урон HP = стакам, затем стаки уменьшаются вдвое
export async function bleedTick(itemId) {
  let dmg = 0, name = "", hpTxt = "";
  await OBR.scene.items.updateItems([itemId], ([it]) => {
    const d = { ...getData(it) }; dmg = d.bleed || 0; name = nameOf(it); d.bleed = Math.floor(dmg / 2); write(it, d);
    if (dmg && it.metadata[CHAR]) hpTxt = ` → HP ${hit(it, dmg, 0).hp}`;
  });
  OBR.notification.show(dmg ? `${name}: Кровотечение −${dmg} HP${hpTxt}` : `${name}: нет Кровотечения`, dmg ? "WARNING" : "DEFAULT");
}

// Конец раунда: Ожог (HP) и Обморожение (ST) наносят урон и делятся пополам; Разрыв/Тремор/Погружение снимаются
export async function endRound() {
  const items = await OBR.scene.items.getItems((i) => !!i.metadata[META] || !!i.metadata[CHAR]);
  const report = [];
  await OBR.scene.items.updateItems(items.map((i) => i.id), (drafts) => {
    for (const it of drafts) {
      const d = { ...getData(it) }; let hp = 0, st = 0;
      if (d.burn) { hp = d.burn; d.burn = Math.floor(d.burn / 2); }
      if (d.frostbite) { st = d.frostbite; d.frostbite = Math.floor(d.frostbite / 2); }
      delete d.rupture; delete d.tremor; delete d.sinking; delete d.endurance; delete d.recycled_evade;
      for (const t of ["slash", "pierce", "blunt"]) { delete d[t + "_protection"]; delete d[t + "_fragile"]; }
      write(it, d);
      if (it.metadata[CHAR]) { const cc = getChar(it); cc.rUsed = 0; cc.swapped = false; it.metadata[CHAR] = cc; }   // реакции восстанавливаются
      if (!hp && !st) continue;
      const c = it.metadata[CHAR] ? hit(it, hp, st) : null;
      report.push(`${nameOf(it)}: ${hp ? `−${hp} HP` : ""}${hp && st ? ", " : ""}${st ? `−${st} ST` : ""}${c ? ` → HP ${c.hp}, ST ${c.st}` : ""}`);
    }
  });
  OBR.notification.show(report.length ? "Конец раунда — " + report.join(" | ") : "Конец раунда: урона от статусов нет", report.length ? "WARNING" : "DEFAULT");
}

export async function endCombat() {
  const items = await OBR.scene.items.getItems((i) => !!i.metadata[META]);
  await OBR.scene.items.updateItems(items.map((i) => i.id), (d) => d.forEach((it) => delete it.metadata[META]));
}

export const CH = `${NS}/attack`;

// Добавляет стаки статусов токену: fx = [{id:"burn", n:3}, ...]
export async function addStatuses(itemId, fx) {
  await OBR.scene.items.updateItems([itemId], ([it]) => {
    const d = { ...getData(it) };
    for (const f of [...fx].sort((a, b) => (b.id === "poise") - (a.id === "poise"))) setStatus(d, f.id, (d[f.id] || 0) + f.n);   // Poise применяется раньше Critical
    write(it, d);
  });
}

// ---------- Окна расширения: перетаскивание, крестик, Esc ----------
export const WIN = { status: ["popover.html", 440, 620, { left: 70, top: 70 }], attack: ["attack.html", 420, 960, { left: 130, top: 60 }], char: ["character.html", 790, 720, { left: 40, top: 40 }], check: ["check.html", 400, 600, { left: 90, top: 80 }], roll: ["roll.html", 380, 330, { left: 0, top: 0 }], react: ["react.html", 420, 560, { left: 0, top: 0 }], log: ["log.html", 380, 640, { left: 60, top: 70 }] };
export const winId = (n) => `${NS}/win-${n}`;
export const getPos = (n) => { try { return JSON.parse(localStorage.getItem(`limbus-pos-${n}`)) || WIN[n][3]; } catch { return WIN[n][3]; } };
export function openWin(n, id, pos = getPos(n), search = id ? `?id=${id}` : "") {
  const [file, width, height] = WIN[n];
  return OBR.popover.open({
    id: winId(n), url: new URL(`${file}${search}`, import.meta.url).href, width, height, disableClickAway: true,
    anchorReference: "POSITION", anchorPosition: pos, anchorOrigin: { vertical: "TOP", horizontal: "LEFT" }, transformOrigin: n === "roll" || n === "react" ? { vertical: "CENTER", horizontal: "CENTER" } : { vertical: "TOP", horizontal: "LEFT" },
  });
}
export const openAttack = (id) => openWin("attack", id);
export function winInit(n, id) {
  const bar = document.getElementById("bar"), close = () => OBR.popover.close(winId(n));
  document.getElementById("x").onclick = close; addEventListener("keydown", (e) => e.key === "Escape" && close());
  let pos = getPos(n), drag = null, busy = false;
  bar.onpointerdown = (e) => { if (e.target.closest("button")) return; drag = { x: e.clientX, y: e.clientY }; bar.setPointerCapture(e.pointerId); };
  bar.onpointermove = async (e) => {
    if (!drag || busy) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (!dx && !dy) return;
    busy = true; pos = { left: Math.max(0, pos.left + dx), top: Math.max(0, pos.top + dy) };
    try { await openWin(n, id, pos, location.search); } catch {} await new Promise(requestAnimationFrame); busy = false;
  };
  bar.onpointerup = () => { drag = null; try { localStorage.setItem(`limbus-pos-${n}`, JSON.stringify(pos)); } catch {} };
}

// ---------- Проверка характеристик: Nd6 + характеристика + плюс ----------
export const CHECK_CH = `${NS}/check`, REQ_CH = `${NS}/check-req`;
export const coinUrl = (ok) => new URL(`icons/coin_${ok ? "success" : "fail"}.png`, import.meta.url).href;
export const GRADE_RU = { bad: "Ужасно…", ok: "Нормально", good: "Хорошо!" };
// Закономерность из 2d6 (1–6 плохо, 7–10 нормально, 11–12 хорошо): плохо ≤ 3 на кубик, хорошо ≥ 5.5 на кубик
export const bands = (n) => ({ bad: 3 * n, good: Math.ceil(5.5 * n) });
export const gradeOf = (total, n) => { const b = bands(n); return total <= b.bad ? "bad" : total >= b.good ? "good" : "ok"; };
export const rollString = (m) => `${m.dice}d6${m.value >= 0 ? "+" : ""}${m.value}+(${m.bonus})`;

export async function doCheck({ tokenId, stat, dice, bonus = 0, roller }) {
  const [it] = await OBR.scene.items.getItems([tokenId]); if (!it) throw new Error("Токен не найден");
  const value = getChar(it).stats[stat] ?? 0;
  dice = Math.min(4, Math.max(1, Math.round(dice) || 1));
  const rolls = [...crypto.getRandomValues(new Uint32Array(dice))].map((v) => (v % 6) + 1);
  const total = rolls.reduce((a, b) => a + b, 0) + value + bonus;
  await OBR.broadcast.sendMessage(CHECK_CH, { token: tokenId, name: nameOf(it), key: stat, statRu: STAT_KEYS.find((x) => x[0] === stat)[1], value, bonus, dice, rolls, total, grade: gradeOf(total, dice), t: Date.now(), roller: roller || OBR.player.id }, { destination: "ALL" });
}

// Журнал (Log) хранится у каждого клиента: все получают бросок через broadcast
const lk = () => `limbus-log-${OBR.room.id}`;
export const logGet = () => { try { return JSON.parse(localStorage.getItem(lk())) || []; } catch { return []; } };
export const logPush = (m) => { try { const l = logGet(); if (l[0]?.t === m.t) return; localStorage.setItem(lk(), JSON.stringify([m, ...l].slice(0, 60))); } catch {} };
export const logClear = () => { try { localStorage.removeItem(lk()); } catch {} };
const FACE = { good: ["#3fb34f", "M7 13q4 4 8 0"], ok: ["#f0a020", "M7 14h8"], bad: ["#d1352f", "M7 15q4-4 8 0"] };
export const face = (g) => `<svg viewBox="0 0 22 22" width="22" height="22"><circle cx="11" cy="11" r="10" fill="${FACE[g][0]}"/><circle cx="8" cy="9" r="1.4" fill="#111"/><circle cx="14" cy="9" r="1.4" fill="#111"/><path d="${FACE[g][1]}" stroke="#111" stroke-width="1.6" fill="none" stroke-linecap="round"/></svg>`;
export const cardHTML = (m) => `<div class="lcard"><div class="lbar"><img src="icons/stat_${m.key}.png" alt=""><b>${m.statRu}</b><span class="tot ${m.grade}">${m.total}</span></div>
<div class="lmeta"><b>От:</b> ${m.name}<br><b>Бросок:</b> ${rollString(m)} <i>[${m.rolls.join(" + ")}]</i></div>
<div class="lres ${m.grade}">${GRADE_RU[m.grade]} ${face(m.grade)}</div></div>`;

// Poise при попадании: бросок d10 ≤ Poise → Критический удар (весь Poise теряется) ИЛИ +1 Critical и Poise → 1
export async function attackPoise(attackerId, mode) {
  const out = { extraHp: 0 }; let msg = "";
  await OBR.scene.items.updateItems([attackerId], ([it]) => {
    const d = { ...getData(it) }, p = d.poise || 0; if (p <= 0) return;
    const d10 = (n) => [...crypto.getRandomValues(new Uint32Array(n))].map((v) => (v % 10) + 1), roll = d10(1)[0], name = nameOf(it);
    if (roll > p) { msg = `${name}: Poise ${p}, d10 = ${roll} — не сработал`; return; }
    if (mode === "stack") { d.poise = 1; d.critical = (d.critical || 0) + 1; msg = `${name}: Poise сработал (d10 = ${roll} ≤ ${p}): +1 Critical, Poise → 1`; }
    else {
      const n = Math.max(1, d.critical || 0), rolls = d10(n); out.extraHp = rolls.reduce((a, b) => a + b, 0);
      delete d.poise; delete d.critical; msg = `${name}: КРИТИЧЕСКИЙ УДАР (d10 = ${roll} ≤ ${p}): +${out.extraHp} HP урона (${n}d10: ${rolls.join("+")})`;
    }
    write(it, d);
  });
  if (msg) OBR.notification.show(msg, out.extraHp ? "WARNING" : "DEFAULT");
  return out;
}

// ---------- Реакции и Clash ----------
export const REACT_CH = `${NS}/react`;
export const reactionsLeft = (c) => Math.max(0, derived(c).reactions - (c.rUsed || 0));
export async function rawDamage(id, { hp = 0, st = 0 }) {   // урон без сопротивлений (например ST атакующему при победе Блока)
  await OBR.scene.items.updateItems([id], ([it]) => { if (it.metadata[CHAR]) hit(it, hp, st); });
}
export async function healSt(id, n) { await setChar(id, (c) => { const d = derived(c); c.st = Math.min(d.st, (c.st ?? d.st) + n); }); }
