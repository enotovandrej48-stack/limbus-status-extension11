// Чтобы добавить свою анимацию: положите кадры 00.png, 01.png... в anims/<id>/ и добавьте строку сюда.
export const ANIMS = [
  { id: "slash_1", ru: "Режущий: обычный удар", type: "slash", frames: 10, fps: 16 },
  { id: "slash_2", ru: "Режущий: множественный", type: "slash", frames: 15, fps: 16 },
  { id: "slash_3", ru: "Режущий: сильный удар", type: "slash", frames: 14, fps: 14 },
  { id: "pierce_1", ru: "Пронзающий: обычный удар", type: "pierce", frames: 10, fps: 16 },
  { id: "pierce_2", ru: "Пронзающий: множественный", type: "pierce", frames: 15, fps: 16 },
  { id: "pierce_3", ru: "Пронзающий: сильный удар", type: "pierce", frames: 14, fps: 14 },
  { id: "blunt_1", ru: "Дробящий: обычный удар", type: "blunt", frames: 10, fps: 16 },
  { id: "blunt_2", ru: "Дробящий: множественный", type: "blunt", frames: 15, fps: 16 },
  { id: "blunt_3", ru: "Дробящий: сильный удар", type: "blunt", frames: 16, fps: 14 },
  { id: "combo", ru: "Комбо: режущий + пронзающий + дробящий", type: "combo", frames: 18, fps: 16 },
  { id: "hammer", ru: "Молот Корп. N: суд", type: "hammer", frames: 26, fps: 16, w: 512, h: 268, ax: 0.616, ay: 0.488 },
  { id: "hammer_azure", ru: "Молот: лазурный, с обводкой", type: "hammer", frames: 26, fps: 16, w: 512, h: 268, ax: 0.616, ay: 0.488 },
];
export const TYPES = { slash: "Режущие", pierce: "Пронзающие", blunt: "Дробящие", combo: "Комбо", hammer: "Молот Корп. N (из игры)" };
export const animFrames = (a) => Array.from({ length: a.frames }, (_, i) => new URL(`anims/${a.id}/${String(i).padStart(2, "0")}.png`, import.meta.url).href);
