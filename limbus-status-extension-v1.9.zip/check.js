import { OBR, NS, CHECK_CH, REQ_CH, iconUrl, openWin, logPush, GRADE_RU } from "./common.js";

OBR.onReady(() => {
  OBR.contextMenu.create({
    id: `${NS}/check`,
    icons: [{ icon: iconUrl("coin_success"), label: "Проверка", filter: { max: 1, every: [{ key: "layer", value: "CHARACTER", coordinator: "||" }, { key: "layer", value: "MOUNT", coordinator: "||" }, { key: "layer", value: "PROP" }] } }],
    onClick: (ctx) => openWin("check", ctx.items[0].id),
  });
  // результат проверки: запись в Log + окно с анимацией монет по центру экрана (закрывается само)
  OBR.broadcast.onMessage(CHECK_CH, async (e) => {
    const m = e.data; logPush(m);
    if (m.roller === OBR.player.id) try {   // анимация только у того, кто бросает
      const [w, h] = await Promise.all([OBR.viewport.getWidth(), OBR.viewport.getHeight()]);
      await openWin("roll", null, { left: w / 2, top: h / 2 }, "?m=" + encodeURIComponent(JSON.stringify(m)));
    } catch (err) { console.error(err); }
    setTimeout(() => OBR.notification.show(`${m.name}: ${m.statRu} — ${GRADE_RU[m.grade]} (${m.total})`, m.grade === "bad" ? "ERROR" : m.grade === "ok" ? "WARNING" : "SUCCESS"), 1600);
  });
  // запрос проверки от мастера (или передача от другого игрока)
  OBR.broadcast.onMessage(REQ_CH, async (e) => {
    const d = e.data; if (d.to !== OBR.player.id) return;
    if (d.kind === "info") return OBR.notification.show(d.text, "INFO");
    if (d.kind === "ask") {
      OBR.notification.show(`${d.fromName || d.byName || "Мастер"} просит вас сделать проверку`, "INFO");
      try { await openWin("check", null, undefined, "?req=" + encodeURIComponent(JSON.stringify(d))); } catch (err) { console.error(err); }
    }
  });
});
