import { OBR, CHAR, REACT_CH, STATUSES, getChar, derived, getData, nameOf, setChar, addStatuses, applyDamage, rawDamage, healSt, attackPoise, reactionsLeft, activeWeapon, defense, applyRows, openWin } from "./common.js";

const pending = new Map(), sleep = (ms) => new Promise((r) => setTimeout(r, ms)), sgn = (v) => (v ? (v > 0 ? "+" : "") + v : "");

// кубик 1dX + сила (бонус)
function roll(max, bonus = 0) { const v = (crypto.getRandomValues(new Uint32Array(1))[0] % max) + 1; return { total: v + bonus, label: `1d${max}${sgn(bonus)}`, die: v }; }
// Clash: бросают обе стороны, больше — победа, при равенстве перебрасывают
function clash(amax, ab, dmax, db) { let a, d, i = 0; do { a = roll(amax, ab); d = roll(dmax, db); } while (a.total === d.total && ++i < 20); return { a, d, defWins: d.total > a.total }; }

export function initClash() {
  OBR.broadcast.onMessage(REACT_CH, async (e) => {
    const d = e.data;
    if (d.kind === "resp") return pending.get(d.rid)?.(d);
    if (d.kind === "ask" && d.to === OBR.player.id) {   // менюшка реакции у защищающегося
      try {
        const [w, h] = await Promise.all([OBR.viewport.getWidth(), OBR.viewport.getHeight()]);
        await openWin("react", null, { left: w / 2, top: h / 2 }, "?m=" + encodeURIComponent(JSON.stringify(d)));
      } catch (err) { console.error(err); OBR.notification.show(`${d.tName}: на вас нападает ${d.aName}!`, "WARNING"); }
    }
  });
}

// параметры атаки: кубик оружия (1d8/1d10/1d12) + сила кубика оружия + модификатор атаки (ранг)
function atkInfo(m, ca, da) { const w = activeWeapon(ca), max = +m.atkDie || w.max; return { w, max, bonus: w.pow + da.att, type: m.dmg?.type || w.type }; }

// кто решает за цель: игрок, за которым закреплён лист, иначе GM
async function askReaction(m, A, T, a) {
  const c = getChar(T), fx = getData(T), df = defense(c, fx), wd = activeWeapon(c), dt = derived(c), left = reactionsLeft(c), rec = fx.recycled_evade || 0;
  if (left <= 0 && rec <= 0) return { reaction: "none" };   // реакций нет — просто урон
  const me = OBR.player.id, role = await OBR.player.getRole(), ps = await OBR.party.getPlayers();
  const ctrl = c.access === "player" && c.owner && (c.owner === me || ps.some((p) => p.id === c.owner)) ? c.owner : role === "GM" ? me : ps.find((p) => p.role === "GM")?.id;
  if (!ctrl) return { reaction: "none" };
  const rid = crypto.randomUUID();
  const ask = { kind: "ask", rid, to: ctrl, aName: nameOf(A), tName: nameOf(T), atk: `${a.w.name}: 1d${a.max}${sgn(a.bonus)}`, left, rec,
    block: `1d${df.bmax}${sgn(df.bbonus)}`, evade: `1d${df.emax}${sgn(df.ebonus - df.step * rec)}`, counter: `${wd.name}: 1d${wd.max}${sgn(wd.pow + dt.att)}`,
    canBlock: left > 0, canEvade: left > 0 || rec > 0, canCounter: left > 0 };
  const wait = new Promise((res) => pending.set(rid, res));
  await OBR.broadcast.sendMessage(REACT_CH, ask, { destination: "ALL" });
  OBR.notification.show(`${ask.tName} может среагировать на атаку…`);
  const r = await Promise.race([wait, sleep(120000).then(() => ({ reaction: "none" }))]); pending.delete(rid); return r;
}

async function applyFx(m, A, T) {   // статусы из окна атаки (дополнительно к эффектам оружия)
  const ru = (id) => STATUSES.find((s) => s.id === id)?.ru || id;
  const mine = m.fx.filter((f) => f.who === "me"), his = m.fx.filter((f) => f.who !== "me");
  try {
    if (his.length) await addStatuses(m.to, his);
    if (mine.length) await addStatuses(m.from, mine);
    OBR.notification.show(m.fx.map((f) => `${nameOf(f.who === "me" ? A : T)}: +${f.n} ${ru(f.id)}`).join(" | "));
  } catch (e) { OBR.notification.show("Не удалось добавить статусы: " + e.message, "ERROR"); }
}

// Вызывает только тот, кто запустил атаку (после анимации). Урон = итоговый результат броска атаки (по правилам книги)
export async function resolveAttack(m) {
  const its = await OBR.scene.items.getItems([m.from, m.to]), A = its.find((i) => i.id === m.from), T = its.find((i) => i.id === m.to);
  if (!A || !T) return;
  const ca = getChar(A), da = derived(ca), ct = getChar(T), dt = derived(ct), fxT = getData(T), o = ct.outfit, df = defense(ct, fxT), wd = activeWeapon(ct);
  const a = atkInfo(m, ca, da), w = a.w, an = nameOf(A), tn = nameOf(T);
  const ch = T.metadata[CHAR] ? await askReaction(m, A, T, a) : { reaction: "none" };
  const spend = () => setChar(m.to, (c) => { c.rUsed = (c.rUsed || 0) + 1; });
  const eff = [], fx = async (rows, owner, opp) => eff.push(...(await applyRows(rows, owner, opp)));
  let final = 0, hits = true, msg;

  if (ch.reaction === "block") {
    const r = clash(a.max, a.bonus, df.bmax, df.bbonus); await spend();
    const vs = `Блок ${tn} ${r.d.label}=${r.d.total} против ${an} ${r.a.label}=${r.a.total}`;
    if (r.defWins) {
      hits = false; const diff = r.d.total - r.a.total, st = o.prop === "armored" ? Math.max(diff, Math.floor(r.d.total / 2)) : diff, melee = w.kind !== "ranged";
      if (melee) await rawDamage(m.from, { st });
      msg = `${vs}: атака отменена${melee ? `, ${an} получает ${st} ST` : ""}`;
      await fx(o.bw, m.to, m.from); await fx(w.lose, m.from, m.to);
    } else { final = Math.max(0, r.a.total - r.d.total); msg = `${vs}: блок проигран, итог атаки ${final}`; await fx(o.bl, m.to, m.from); }
  } else if (ch.reaction === "evade") {
    const rec = fxT.recycled_evade || 0, r = clash(a.max, a.bonus, df.emax, df.ebonus - df.step * rec);
    if (!rec) await spend();   // Recycled Evade не тратит реакцию
    const vs = `Уклонение ${tn} ${r.d.label}=${r.d.total} против ${an} ${r.a.label}=${r.a.total}`;
    if (r.defWins) {
      hits = false; await healSt(m.to, r.d.total); await addStatuses(m.to, [{ id: "recycled_evade", n: 1 }]);
      msg = `${vs}: атака отменена, ${tn} восстанавливает ${r.d.total} ST и получает Recycled Evade`;
      await fx(o.ew, m.to, m.from); await fx(w.lose, m.from, m.to);
    } else { final = Math.max(0, r.a.total); msg = `${vs}: уклониться не удалось, итог атаки ${final}`; await fx(o.el, m.to, m.from); }
  } else if (ch.reaction === "counter") {
    const r = clash(a.max, a.bonus, wd.max, wd.pow + dt.att); await spend();
    const vs = `Контратака ${tn} (${wd.name}) ${r.d.label}=${r.d.total} против ${an} ${r.a.label}=${r.a.total}`;
    if (r.defWins) {
      hits = false;
      if (ch.inRange !== false) { await applyDamage(m.from, { hp: r.d.total, st: r.d.total, type: wd.type }); msg = `${vs}: атака отменена, ${an} получает контрудар`; }
      else msg = `${vs}: атака отменена, но цель вне радиуса оружия`;
      await fx(wd.win, m.to, m.from); await fx(w.lose, m.from, m.to);
    } else { final = Math.max(0, r.a.total); msg = `${vs}: контратака проиграла, итог атаки ${final}`; await fx(wd.lose, m.to, m.from); }
  } else {
    const r = roll(a.max, a.bonus); final = Math.max(0, r.total);
    msg = `${an} (${w.name}) бросает ${r.label}=${r.total} без противодействия: одностороннее нападение, эффекты On Clash Win срабатывают`;
  }
  OBR.notification.show(msg, hits ? "WARNING" : "SUCCESS");

  if (hits) {
    let extra = 0;   // Poise: бросок при попадании
    if (m.poise && m.poise !== "off") extra = (await attackPoise(m.from, m.poise).catch(() => ({ extraHp: 0 }))).extraHp;
    // HP DMG = (итог × сопротивление HP) ; ST DMG = (итог × сопротивление ST) — считается в applyDamage
    await applyDamage(m.to, { hp: final + extra, st: final, type: a.type }).catch((e) => OBR.notification.show("Урон не применён: " + e.message, "ERROR"));
    await fx(w.win, m.from, m.to);
    if (m.fx?.length) await applyFx(m, A, T);
  }
  if (eff.length) OBR.notification.show("Эффекты оружия/брони: " + eff.join(" | "));
}
