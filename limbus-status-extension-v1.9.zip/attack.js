import { OBR, buildImage, NS, CH, iconUrl, addStatuses, nameOf, STATUSES, attackPoise, openAttack, openWin, bleedTick, applyDamage, getData } from "./common.js";
import { ANIMS, animFrames } from "./anims.js";
import { initClash, resolveAttack } from "./clash.js";

const FLAG = `${NS}/anim`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

OBR.onReady(() => {
  initClash();
  OBR.contextMenu.create({
    id: `${NS}/attack`,
    icons: [{
      icon: iconUrl("attack"), label: "Атака",
      filter: { max: 1, every: [{ key: "layer", value: "CHARACTER", coordinator: "||" }, { key: "layer", value: "MOUNT", coordinator: "||" }, { key: "layer", value: "PROP" }] },
    }],
    onClick: (ctx) => openAttack(ctx.items[0].id),
  });
  OBR.contextMenu.create({
    id: `${NS}/char`,
    icons: [{ icon: iconUrl("char"), label: "Персонаж", filter: { max: 1, every: [{ key: "layer", value: "CHARACTER", coordinator: "||" }, { key: "layer", value: "MOUNT", coordinator: "||" }, { key: "layer", value: "PROP" }] } }],
    onClick: (ctx) => openWin("char", ctx.items[0].id),
  });
  // сообщение приходит всем игрокам (и отправителю) — каждый проигрывает анимацию у себя
  OBR.broadcast.onMessage(CH, (e) => play(e.data).catch(console.error));
});

async function play(m) {
  const anim = ANIMS.find((a) => a.id === m.anim);
  const items = await OBR.scene.items.getItems([m.from, m.to]);
  const from = items.find((i) => i.id === m.from), to = items.find((i) => i.id === m.to);
  if (!anim || !from || !to) return;

  // атакующий совершает действие: Кровотечение наносит ему урон (делает только отправитель)
  if (m.sender === OBR.player.id && getData(from).bleed > 0) bleedTick(m.from).catch(console.error);
  const [dpi, scale] = await Promise.all([OBR.scene.grid.getDpi(), OBR.scene.grid.getScale()]);
  const px = (m.feet / (scale.parsed?.multiplier || 5)) * dpi;           // размер в пикселях сцены
  const angle = (Math.atan2(to.position.y - from.position.y, to.position.x - from.position.x) * 180) / Math.PI;
  const urls = animFrames(anim);
  urls.forEach((u) => { new Image().src = u; });                         // прогрев кэша, чтобы не мигало

  const aw = anim.w || 256, ah = anim.h || 256;
  const fx = buildImage({ width: aw, height: ah, url: urls[0], mime: "image/png" }, { dpi: (aw * dpi) / px, offset: { x: (anim.ax ?? 0.5) * aw, y: (anim.ay ?? 0.5) * ah } })
    .position(to.position).rotation(angle).layer("ATTACHMENT").zIndex(100000)
    .disableHit(true).locked(true).metadata({ [FLAG]: true }).build();
  await OBR.scene.local.addItems([fx]);

  const step = 1000 / (anim.fps * (m.speed || 1));
  for (let i = 1; i < urls.length; i++) {
    await sleep(step);
    await OBR.scene.local.updateItems([fx.id], ([it]) => { it.image.url = urls[i]; });
  }
  await sleep(step);
  await OBR.scene.local.deleteItems([fx.id]);

  if (m.sender === OBR.player.id) await resolveAttack(m).catch((e) => OBR.notification.show("Ошибка боя: " + e.message, "ERROR"));
}
